import React from "react";
import "./Home.css";

const Home: React.FC = () => {
  console.log("Home component loaded"); // Debugging log

  return (
    <div className="page-container">
      <h1>Welcome to the Home Page</h1>
    </div>
  );
};

export default Home;
